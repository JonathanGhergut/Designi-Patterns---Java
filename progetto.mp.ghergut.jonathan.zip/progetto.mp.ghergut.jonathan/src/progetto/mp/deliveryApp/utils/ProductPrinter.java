package progetto.mp.deliveryApp.utils;

public interface ProductPrinter {

	void print(String message);

}
