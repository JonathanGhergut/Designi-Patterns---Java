package progetto.mp.deliveryApp.utils;

public interface FoodReview {

	void review(ProductPrinter printer);
}
