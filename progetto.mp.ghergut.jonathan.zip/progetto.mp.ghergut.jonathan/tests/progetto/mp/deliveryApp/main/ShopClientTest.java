package progetto.mp.deliveryApp.main;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;

import progetto.mp.deliveryApp.utils.DeliveryTipVisitor;
import progetto.mp.deliveryApp.utils.MockProductPrinter;
import progetto.mp.deliveryApp.utils.ProductInfoVisitor;
import progetto.mp.deliveryApp.utils.ProductPrinter;

public class ShopClientTest {

	private ShopClient client;
	private ProductPrinter printer;

	@Before
	public void init() {
		client = new ShopClient();
		printer = new MockProductPrinter();
	}
	
	@Test
	public void testAddCrepes() {
		
		client.addCrepes();
		client.addCrepes();
		assertThat(client.getFoods()).size().isEqualTo(2);
	}

	@Test
	public void testAddAnIceCream() {
		
		client.addIceCream();
		assertThat(client.getFoods()).size().isEqualTo(1);
	}
	@Test
	public void testAddATea() {
		
		client.addTea();
		assertThat(client.getBeverages()).size().isEqualTo(1);
	}
	
	@Test
	public void testAddALemonade() {
		
		client.addLemonade();
		client.addLemonade();
		assertThat(client.getBeverages()).size().isEqualTo(2);
	}
	
	@Test
	public void testRemoveALemonade() {
		
		client.addLemonade();
		client.removeLemonade();
		assertThat(client.getBeverages()).size().isEqualTo(0);
	}
	
	@Test
	public void testRemoveATea() {
		
		client.addTea();
		client.removeTea();
		assertThat(client.getBeverages()).size().isEqualTo(0);
	}
	
	@Test
	public void testRemoveAnIceCream() {
		
		client.addIceCream();
		client.addLemonade();
		client.removeIceCream();
		assertThat(client.getBeverages()).size().isEqualTo(1);
		assertThat(client.getFoods()).size().isEqualTo(0);

	}
	@Test
	public void testRemoveACrepes() {
		
		client.addCrepes();
		client.addLemonade();
		client.removeCrepes();
		assertThat(client.getFoods()).size().isEqualTo(0);
	}
	
	@Test
	public void testWrongFoodRemove() {
		
		client.addCrepes();
		client.addLemonade();
		NoSuchElementException nee = assertThrows(NoSuchElementException.class, 
				() -> client.removeIceCream() );
		
		assertEquals ("This food isn't in your shopping cart!", nee.getMessage());
		assertThat(client.getFoods()).size().isEqualTo(1);
		
	}
	
	@Test
	public void testWrongBeverageRemove() {
		
		client.addLemonade();
		client.addLemonade();
		
		NoSuchElementException nee = assertThrows(NoSuchElementException.class, 
				() -> client.removeTea() );
		
		assertEquals ("This beverage isn't in your shopping cart!", nee.getMessage());
		assertThat(client.getBeverages()).size().isEqualTo(2);
		
	}
	
	@Test
	public void testTotalOrderCost() {
		
		client.addLemonade();
		client.addLemonade();
		client.addCrepes();
		
		assertEquals(13.0, client.totalOrderCost(),0);
	}
	
	@Test
	public void testTotalOrderCostWithDelivery() {
		
		client.addLemonade();
		client.addLemonade();
		client.addCrepes();
		
		assertEquals(18.0, 
				client.totalOrderCostWithDelivery(new DeliveryTipVisitor(printer,5.0)),0);
	}
	
	@Test
	public void testTotalElementInShoppingCart() {
		
		client.addLemonade();
		client.addCrepes();
		client.addTea();
		client.addIceCream();
		
		assertEquals(4, client.numberOfProductsInShoppingCart());
	}
	
	@Test
	public void testShowYourShoppingCart() {
		

		client.addLemonade();
		client.addCrepes();
		client.addTea();
		client.addIceCream();
		
		client.lookAtYourShoppingCart(printer, new ProductInfoVisitor(printer));
		assertEquals("Your shopping cart: \n"
				+ "Lemonade, with cost: 4.0\n"
				+ "Tea, with cost: 4.0\n"
				+ "Crepes, with cost: 5.0\n"
				+ "IceCream, with cost: 3.5\n",
				printer.toString());
	}
}
