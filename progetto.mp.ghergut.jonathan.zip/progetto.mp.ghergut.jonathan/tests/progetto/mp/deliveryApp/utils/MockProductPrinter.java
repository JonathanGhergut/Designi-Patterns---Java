package progetto.mp.deliveryApp.utils;

public class MockProductPrinter implements ProductPrinter{

	private StringBuilder builder = new StringBuilder();
	
	@Override
	public void print(String message) {
		builder.append(message +"\n");
	}

	@Override
	public String toString() {
		return builder.toString();
	}

}
