package progetto.mp.deliveryApp.utils;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import progetto.mp.deliveryApp.main.Food;


public class ProductReviewDecoratorTest {

	private MockProductPrinter printer;
	private ProductFactory hpf;
	private ProductFactory cpf;

	
	@Before
	public void init() {
		printer = new MockProductPrinter();
		hpf = new HotProductFactory();
		cpf = new ColdProductFactory();
	}
	
	@Test
	public void testClientReview() {
		
		Food iceCream = cpf.orderFood();
		new ClientReview("Good Choise", iceCream).review(printer);
		assertEquals("About IceCream: Good Choise\n", printer.toString());
		
	}
	
	@Test
	public void testDataReviewDecorator() {
		
		Food iceCream = cpf.orderFood();
		new DataReviewDecorator(
				new ClientReview("Good Choise", iceCream),
					"Data: 23/01/2023"
			).review(printer);
		
		assertEquals("Data: 23/01/2023\n" 
				+ "About IceCream: Good Choise\n", printer.toString());
		
	}
	
	@Test
	public void testStarsReviewDecorator() {
		
		Food crepes = hpf.orderFood();
		new StarsReviewDecorator(
				new ClientReview("Good nutella", crepes),
				"I gave it 5 stars")
		.review(printer);
		
		assertEquals("About Crepes: Good nutella\n"+
					"I gave it 5 stars\n", printer.toString());
	}

	@Test
	public void testDataAndStarsReviewDecorator() {
		
		Food crepes = hpf.orderFood();
		new DataReviewDecorator(
				new StarsReviewDecorator(
						new ClientReview("Incredible", crepes),
							"I gave it 5 stars"),
				"Data: 23/01/2023")
		.review(printer);
		
		assertEquals("Data: 23/01/2023\n" +
					"About Crepes: Incredible\n" +
					"I gave it 5 stars\n", printer.toString());
	}
}
