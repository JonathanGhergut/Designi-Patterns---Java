package progetto.mp.deliveryApp.utils;

import static org.junit.Assert.*;


import org.junit.Before;
import org.junit.Test;

import progetto.mp.deliveryApp.main.Beverage;
import progetto.mp.deliveryApp.main.Food;

public class DeliveryTipVisitorTest {

	private MockProductPrinter printer;
	private DeliveryTipVisitor visitor;
	ProductFactory cpf;
	ProductFactory hpf; 

	
	@Before
	public void init() {
		printer = new MockProductPrinter();
		cpf = new ColdProductFactory();
		hpf = new HotProductFactory();
	}
	
	@Test
	public void testWrongTip() {
		Beverage lem = cpf.orderBeverage();
		visitor = new DeliveryTipVisitor(printer, 5.0);
		lem.accept(visitor);
		IllegalArgumentException iae = assertThrows(IllegalArgumentException.class, 
				() -> visitor = new DeliveryTipVisitor(printer, 0.0));
		
		assertEquals ("You must add a tip for our delivery!", iae.getMessage());
	}
	
	@Test
	public void testLemonadeReview() {
		Beverage lem = cpf.orderBeverage();
		visitor = new DeliveryTipVisitor(printer, 5.0);
		lem.accept(visitor);
		assertEquals("Lemonade's cost: €4.0"+
							"\nThank for your tip: €5.0\n", printer.toString());
	}
	
	@Test
	public void testTeaReview() {
		Beverage tea = hpf.orderBeverage();
		visitor = new DeliveryTipVisitor(printer, 5.0);
		tea.accept(visitor);
		assertEquals("Tea's cost: €4.0"+
							"\nThank for your tip: €5.0\n", printer.toString());
	}
	
	@Test
	public void testCrepesReview() {
		Food crepes = hpf.orderFood();
		visitor = new DeliveryTipVisitor(printer, 5.0);
		crepes.accept(visitor);
		assertEquals("Crepes' cost: €5.0"+
							"\nThank for your tip: €5.0\n", printer.toString());
	}
	
	@Test
	public void testIceCreamReview() {
		Food ice = cpf.orderFood();
		visitor = new DeliveryTipVisitor(printer, 5.0);
		ice.accept(visitor);
		assertEquals("IceCream's cost: €3.5"+
							"\nThank for your tip: €5.0\n", printer.toString());
	}

}
