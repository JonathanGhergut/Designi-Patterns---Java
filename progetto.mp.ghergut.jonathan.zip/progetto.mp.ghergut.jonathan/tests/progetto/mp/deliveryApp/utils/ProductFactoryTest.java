package progetto.mp.deliveryApp.utils;

import static org.junit.Assert.*;


import org.junit.Test;

import progetto.mp.deliveryApp.main.Beverage;
import progetto.mp.deliveryApp.main.Food;


public class ProductFactoryTest {

	@Test
	public void testHotProductFactoryPrice() {
		
		ProductFactory hpf = new HotProductFactory();
		
		Beverage tea = hpf.orderBeverage();
		Food crepes = hpf.orderFood();
		
		assertEquals(4.0, tea.cost(),0);
		assertEquals(5.0, crepes.cost(), 0);
	} 

	@Test
	public void testColdProductFactoryPrice() {
		
		ProductFactory cpf = new ColdProductFactory();
		Beverage lem = cpf.orderBeverage();
		Food iceCream = cpf.orderFood();
		
		assertEquals(4.0, lem.cost(),0); 
		assertEquals(3.5, iceCream.cost(),0);
	}
	
	@Test
	public void testHotProductFactoryProduct() {
		
		ProductFactory hpf = new HotProductFactory();
		
		Beverage tea = hpf.orderBeverage();
		Food crepes = hpf.orderFood();
		
		assertEquals("Tea",tea.product());
		assertEquals("Crepes", crepes.product());
	}

	@Test
	public void testColdProductFactoryProduct() {
		
		ProductFactory cpf = new ColdProductFactory();
		Beverage lem = cpf.orderBeverage();
		Food iceCream = cpf.orderFood();
		
		assertEquals("Lemonade", lem.product()); 
		assertEquals("IceCream", iceCream.product());
	}
}
