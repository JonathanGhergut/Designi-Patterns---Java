package progetto.mp.deliveryApp.utils;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import progetto.mp.deliveryApp.main.Beverage;
import progetto.mp.deliveryApp.main.Food;

public class ProductInfoVisitorTest {

	private MockProductPrinter printer;
	private ProductInfoVisitor visitor;
	ProductFactory cpf;
	ProductFactory hpf; 

	
	@Before
	public void init() {
		printer = new MockProductPrinter();
		visitor = new ProductInfoVisitor(printer);
		cpf = new ColdProductFactory();
		hpf = new HotProductFactory();
	}
	
	@Test
	public void testLemonadeInfo() {
		Beverage lem = cpf.orderBeverage();
		lem.accept(visitor);
		assertEquals("Lemonade, with cost: 4.0\n", printer.toString());
	}
	
	@Test
	public void testTeaInfo() {
		Beverage tea = hpf.orderBeverage();
		tea.accept(visitor);
		assertEquals("Tea, with cost: 4.0\n", printer.toString());
	}
	
	@Test
	public void testCrepesInfo() {
		Food crepes = hpf.orderFood();
		crepes.accept(visitor);
		assertEquals("Crepes, with cost: 5.0\n", printer.toString());
	}
	
	@Test
	public void testIceCreamInfo() {
		Food ice = cpf.orderFood();
		ice.accept(visitor);
		assertEquals("IceCream, with cost: 3.5\n", printer.toString());
	}
}
